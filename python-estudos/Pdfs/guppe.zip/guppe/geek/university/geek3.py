

def funcao3():
    return 'Geek'

